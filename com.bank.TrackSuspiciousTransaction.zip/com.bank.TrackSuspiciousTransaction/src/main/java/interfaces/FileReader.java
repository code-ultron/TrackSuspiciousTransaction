package interfaces;

import java.io.FileNotFoundException;

public interface FileReader {
	public void importDataIntoService() throws FileNotFoundException;
}
