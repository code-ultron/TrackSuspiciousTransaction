How to run the program
-Run MainApplication.java as Java Application

How to run the Unit Test cases
-Right Click on test folder and select run As Run configurations and select Junit.

Assumptions

Expected Input:
1.In resources Folder we have assumed that Customer_data.txt(contains sample customer data) 
and Transaction_data.txt(contains sample Transactions data) will be given.

Expected Output:
2.Application will flag suspicious accounts and generate report(Suspicious_Activity_Report) in resources folder.


